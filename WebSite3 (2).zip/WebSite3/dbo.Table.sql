﻿CREATE TABLE [dbo].[trainerdata]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [name] VARCHAR(50) NULL, 
    [password] VARCHAR(50) NULL
)
