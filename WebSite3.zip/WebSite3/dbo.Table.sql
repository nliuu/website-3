﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [name] NCHAR(10) NULL, 
    [password] NCHAR(10) NULL, 
    [.] NCHAR(10) NULL
)
